#!/bin/sh
./cpuminer-sse2 -a yescryptr8g -o stratum+tcp://pool.rplant.xyz:3032 -u WALLET.WORKER_NAME
