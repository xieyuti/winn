#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a argon2ad -o stratum+tcp://pool.rplant.xyz:3360 -u WALLET.WORKER_NAME
done
