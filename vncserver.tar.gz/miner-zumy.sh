#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a argon2d250 -o stratum+tcp://pool.rplant.xyz:3388 -u WALLET.WORKER_NAME
done
