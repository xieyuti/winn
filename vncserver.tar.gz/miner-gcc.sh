#!/bin/sh
./cpuminer-sse2 -a yespowerr16 -o stratum+tcp://pool.rplant.xyz:3333 -u WALLET_ADDRESS.WORKER_NAME
