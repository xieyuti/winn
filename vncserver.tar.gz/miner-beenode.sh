#!/bin/sh
./cpuminer-sse2 -a honeycomb -o stratum+tcp://pool.rplant.xyz:7017 -u WALLET_ADDRESS.WORKER_NAME
