#!/bin/sh
./cpuminer-sse2 -a yenten -o stratum+tcp://pool.rplant.xyz:3382 -u WALLET_ADDRESS.WORKER_NAME
