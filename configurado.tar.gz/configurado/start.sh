./minerd -a yespower -o stratum+tcp://ru.koto.multipool.online:3032 -u k1AGyct4Lmbdq2pWq1T7W56YEvniTLY25Pc.ubstart
