#!/bin/sh

./start.sh --help

