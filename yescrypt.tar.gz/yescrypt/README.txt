minerd-sse2.exe      Core2, Nehalem
minerd-aes-sse42.exe Westmere, Sandy-Ivybridge
minerd-avx.exe       Sandy-Ivybridge
minerd-avx2.exe      Haswell, Sky-Kaby-Coffeelake
minerd-xop.exe       AMD FX
minerd-avx2-sha.exe  Ryzen
