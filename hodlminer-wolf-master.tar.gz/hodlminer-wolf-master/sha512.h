#ifndef _SHA512_H
#define _SHA512_H

#ifndef __AVX2__
#ifndef __SSE2__
#error "Either SSE2 or AVX2 supported needed"
#endif // __SSE2__
#endif // __AVX2__

#include <stdint.h>

#include <emmintrin.h>
#ifdef __AVX2__
#include <immintrin.h>
#endif

//SHA-512 block size
#define SHA512_BLOCK_SIZE 128
//SHA-512 digest size
#define SHA512_DIGEST_SIZE 64

typedef struct
{
#ifdef __AVX2__
   __m256i h[8];
   __m256i w[80];
#else // SSE2
   __m128i h[8];
   __m128i w[80];
#endif
} Sha512Context;

#ifdef __AVX2__
#define SHA512_PARALLEL_N 8
#else // SSE2
#define SHA512_PARALLEL_N 4
#endif

//SHA-512 related functions
void sha512Compute32b_parallel(
        uint64_t *data[SHA512_PARALLEL_N],
        uint64_t *digest[SHA512_PARALLEL_N]);

void sha512ProcessBlock(Sha512Context *context);

#endif
